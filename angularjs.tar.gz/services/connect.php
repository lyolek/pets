<?
define("DB_HOST", 'localhost');
define("DB_NAME", 'pets');
define("DB_USER", 'root');
define("DB_PASS", 'root');
?>